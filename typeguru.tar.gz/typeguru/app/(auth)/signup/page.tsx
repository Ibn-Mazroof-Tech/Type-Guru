"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();

  const [name,     setName    ] = useState("");
  const [email,    setEmail   ] = useState("");
  const [password, setPassword] = useState("");
  const [loading,  setLoading ] = useState(false);
  const [error,    setError   ] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { setError("Password must be at least 8 characters."); return; }
    setLoading(true);
    setError("");

    const res = await fetch("/api/auth/register", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ name, email, password }),
    });

    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Something went wrong.");
      setLoading(false);
      return;
    }

    await signIn("credentials", { email, password, callbackUrl: "/practice" });
  }

  async function handleGoogle() {
    setLoading(true);
    await signIn("google", { callbackUrl: "/practice" });
  }

  return (
    <div className="card p-8 border-brand-cyan/20">
      <div className="text-center mb-7">
        <div className="font-brand text-brand-cyan font-black text-xl tracking-widest mb-1">
          TYPE<span className="text-brand-gold">GURU</span>
        </div>
        <p className="text-text-muted text-sm">Create your free account</p>
      </div>

      {error && (
        <div className="bg-brand-red/10 border border-brand-red/30 text-brand-red text-sm rounded-xl px-4 py-3 mb-4">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs text-text-muted font-medium block mb-1.5">Full Name</label>
          <input type="text" required value={name} onChange={(e) => setName(e.target.value)}
            placeholder="Rahul Sharma" className="input" />
        </div>
        <div>
          <label className="text-xs text-text-muted font-medium block mb-1.5">Email</label>
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com" className="input" />
        </div>
        <div>
          <label className="text-xs text-text-muted font-medium block mb-1.5">Password</label>
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
            placeholder="Min. 8 characters" className="input" />
        </div>
        <button type="submit" disabled={loading} className="btn-primary w-full text-sm mt-1">
          {loading ? "Creating account..." : "Create Free Account →"}
        </button>
      </form>

      <div className="relative my-5">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
        <div className="relative flex justify-center text-xs text-text-muted bg-bg-secondary px-2">or</div>
      </div>

      <button onClick={handleGoogle} disabled={loading}
        className="w-full flex items-center justify-center gap-2 border border-border text-text-primary text-sm py-3 rounded-xl hover:border-brand-cyan/30 transition-all">
        <svg className="w-4 h-4" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Continue with Google
      </button>

      <p className="text-center text-text-muted text-xs mt-5">
        Already have an account?{" "}
        <Link href="/login" className="text-brand-cyan hover:underline">Log in</Link>
      </p>
      <p className="text-center text-text-muted text-[10px] mt-3 leading-relaxed">
        By signing up you agree to our Terms of Service and Privacy Policy.
      </p>
    </div>
  );
}

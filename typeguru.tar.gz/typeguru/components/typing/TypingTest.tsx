"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { ModeSelector, MODES, type ModeId } from "./ModeSelector";
import { StatsBar } from "./StatsBar";
import { UpgradeModal } from "@/components/ui/UpgradeModal";
import { isPro } from "@/lib/utils";

const TEXTS: Record<ModeId, string> = {
  general:
    "The quick brown fox jumps over the lazy dog. Every great typist started exactly where you are right now. Consistent practice each day brings mastery.",
  government:
    "The district magistrate directed all concerned officials to submit their quarterly progress reports by the fifteenth of every month without fail.",
  data:
    "INV-2024-00891 | Amount: Rs.45230.00 | Date: 15-03-2024 | Status: PENDING | Tax: 18% | Net: 38330.51 | Code: ORD-8821",
  coding:
    "const getWPM = (chars: number, mins: number): number => Math.round((chars / 5) / mins); function handleChange(e: React.ChangeEvent<HTMLInputElement>) { setTyped(e.target.value); }",
  arabic:
    "Practice your keyboard skills with dedication every single day. Consistency and focused effort bring true mastery in any script or language system.",
};

export function TypingTest() {
  const { data: session } = useSession();
  const router            = useRouter();
  const userPlan          = session?.user?.plan ?? "free";

  const [mode,    setMode   ] = useState<ModeId>("general");
  const [typed,   setTyped  ] = useState("");
  const [started, setStarted] = useState(false);
  const [done,    setDone   ] = useState(false);
  const [time,    setTime   ] = useState(60);
  const [wpm,     setWpm    ] = useState(0);
  const [acc,     setAcc    ] = useState(100);
  const [errors,  setErrors ] = useState(0);
  const [upgrade, setUpgrade] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startRef = useRef<number | null>(null);

  const text = TEXTS[mode];

  // ── Timer ─────────────────────────────────────────────────
  useEffect(() => {
    if (started && !done) {
      timerRef.current = setInterval(() => {
        setTime((t) => {
          if (t <= 1) {
            clearInterval(timerRef.current!);
            setDone(true);
            setStarted(false);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [started, done]);

  // ── Save result when test ends ─────────────────────────────
  useEffect(() => {
    if (done && session?.user && wpm > 0) {
      fetch("/api/tests", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ wpm, accuracy: acc, errors, mode, duration: 60 }),
      }).catch(console.error);
    }
  }, [done]);

  const handleType = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (!started && val.length === 1) { setStarted(true); startRef.current = Date.now(); }
    setTyped(val);

    if (startRef.current) {
      const mins  = (Date.now() - startRef.current) / 60000;
      const words = val.trim().split(/\s+/).filter(Boolean).length;
      setWpm(mins > 0.01 ? Math.round(words / mins) : 0);
    }

    let ok = 0, er = 0;
    for (let i = 0; i < val.length; i++) {
      if (val[i] === text[i]) ok++; else er++;
    }
    setAcc(val.length > 0 ? Math.round((ok / val.length) * 100) : 100);
    setErrors(er);

    if (val.length >= text.length) {
      clearInterval(timerRef.current!);
      setDone(true);
      setStarted(false);
    }
  }, [started, text]);

  const reset = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    setTyped(""); setStarted(false); setDone(false);
    setTime(60); setWpm(0); setAcc(100); setErrors(0);
    startRef.current = null;
    setTimeout(() => inputRef.current?.focus(), 50);
  }, []);

  const selectMode = (id: ModeId) => { setMode(id); reset(); };
  const modeInfo   = MODES.find((m) => m.id === mode)!;
  const progress   = Math.round((typed.length / text.length) * 100);

  // ── Render typed text with colour coding ──────────────────
  const renderText = () =>
    text.split("").map((char, i) => {
      let style: React.CSSProperties = { color: "#27304A" };
      if (i < typed.length) {
        style = typed[i] === char
          ? { color: "#00E5FF" }
          : { color: "#FF4455", textDecoration: "underline wavy #FF4455" };
      } else if (i === typed.length) {
        style = { color: "#F0F4FF", background: "rgba(0,229,255,0.12)", borderBottom: "2px solid #00E5FF" };
      }
      return (
        <span key={i} style={style} className="font-mono">
          {char === " " ? " " : char}
        </span>
      );
    });

  return (
    <div className="max-w-3xl mx-auto px-5 py-6">
      <UpgradeModal open={upgrade} onClose={() => setUpgrade(false)} />

      <ModeSelector
        selected={mode}
        onSelect={selectMode}
        onUpgrade={() => setUpgrade(true)}
        isPro={isPro(userPlan)}
      />

      <StatsBar wpm={wpm} accuracy={acc} time={time} errors={errors} />

      {/* Typing area */}
      <div
        className="card p-6 mb-3 cursor-text"
        onClick={() => inputRef.current?.focus()}>

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-base">{modeInfo.emoji}</span>
            <span className="text-xs font-bold" style={{ color: modeInfo.color }}>
              {modeInfo.label}
            </span>
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full border"
              style={{ background: modeInfo.color + "18", borderColor: modeInfo.color + "35", color: modeInfo.color }}>
              {modeInfo.sub}
            </span>
          </div>
          {started && !done ? (
            <div className="flex items-center gap-1.5 text-brand-cyan text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-cyan animate-blink inline-block" />
              Recording...
            </div>
          ) : !done ? (
            <span className="text-text-muted text-xs">Click here and start typing ↓</span>
          ) : null}
        </div>

        <div className="text-[15px] leading-[2.1] tracking-wide select-none min-h-[72px]">
          {renderText()}
        </div>

        <input
          ref={inputRef}
          value={typed}
          onChange={handleType}
          disabled={done}
          className="opacity-0 absolute w-px h-px pointer-events-none"
          autoFocus
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
        />
      </div>

      {/* Progress bar */}
      <div className="h-[3px] bg-bg-tertiary rounded-full mb-3">
        <div
          className="h-full rounded-full bg-gradient-to-r from-brand-cyan to-blue-500 transition-[width]"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Result / Controls */}
      {done ? (
        <div className="card p-7 text-center border-brand-cyan/25">
          <p className="text-text-muted text-xs mb-2">Test Complete! 🎉</p>
          <p className="font-mono text-5xl font-bold text-brand-cyan glow-text mb-1">{wpm} WPM</p>
          <p className="text-text-muted text-sm mb-6">
            Accuracy: {acc}% · Errors: {errors}
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <button onClick={reset} className="btn-primary text-sm">↺ Try Again</button>
            {!session && (
              <button onClick={() => router.push("/signup")}
                className="btn-outline text-sm">
                Save Score →
              </button>
            )}
            <button
              onClick={() => router.push("/pricing")}
              className="border border-brand-gold/30 text-brand-gold text-sm px-5 py-2.5 rounded-xl hover:bg-brand-gold/10 transition-all">
              🎓 Get Certificate
            </button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <button onClick={reset}
            className="bg-bg-tertiary text-text-muted border border-border text-xs px-4 py-2.5 rounded-xl hover:text-text-primary transition-all">
            ↺ Restart
          </button>
          <div className="flex-1 card bg-bg-tertiary px-4 py-2.5 text-xs text-text-muted">
            💡 PRO modes (Coding, Arabic) unlock for just ₹11/day
          </div>
        </div>
      )}
    </div>
  );
}
